#!/bin/bash
ruff check . --fix-only
ruff format .
