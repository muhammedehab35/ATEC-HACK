"""OSMnx package version information."""

__version__ = "2.0.0b3"
